import './App.css'
import Todo from './components/todo'

function App() {

  return (
    <>
     <Todo/>
    </>
  )
}

export default App
